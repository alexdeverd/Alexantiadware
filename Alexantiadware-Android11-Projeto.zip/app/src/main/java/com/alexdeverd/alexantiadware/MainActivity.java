package com.alexdeverd.alexantiadware;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout results;
    private TextView summary;
    private final int bg = Color.rgb(11, 18, 38);
    private final int panel = Color.rgb(20, 31, 58);
    private final int blue = Color.rgb(64, 156, 255);
    private final int white = Color.rgb(238, 244, 255);
    private final int muted = Color.rgb(165, 181, 207);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        scanApps();
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, 6, 0, 6);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 24, 22, 24);
        scroll.addView(root);

        TextView title = text("ALEXANTIADWARE", 24, blue);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);
        root.addView(text("Análise de aplicativos • Android 11", 14, muted));
        root.addView(text("Esta versão apenas analisa e gera um resumo. Não desinstala apps, não formata e não restaura o aparelho.", 14, white));

        summary = text("Preparando análise...", 16, white);
        summary.setPadding(14, 14, 14, 14);
        summary.setBackgroundColor(panel);
        root.addView(summary);

        Button scan = new Button(this);
        scan.setText("ANALISAR NOVAMENTE");
        scan.setOnClickListener(v -> scanApps());
        root.addView(scan);

        root.addView(text("APLICATIVOS INSTALADOS", 18, blue));
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);
        root.addView(text("Aviso: os indicadores são heurísticas simples, não comprovam que um aplicativo seja malware.", 12, muted));
        setContentView(scroll);
    }

    private void scanApps() {
        results.removeAllViews();
        PackageManager pm = getPackageManager();
        List<PackageInfo> packages;
        try {
            packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS);
        } catch (Exception e) {
            summary.setText("Não foi possível listar aplicativos: " + e.getMessage());
            return;
        }
        Collections.sort(packages, Comparator.comparing(p -> {
            CharSequence label = p.applicationInfo.loadLabel(pm);
            return label == null ? p.packageName : label.toString();
        }, String.CASE_INSENSITIVE_ORDER));

        int suspicious = 0;
        int userApps = 0;
        for (PackageInfo p : packages) {
            ApplicationInfo ai = p.applicationInfo;
            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            if (!system) userApps++;
            List<String> reasons = new ArrayList<>();
            String[] perms = p.requestedPermissions;
            if (perms != null) {
                for (String permission : perms) {
                    if (permission == null) continue;
                    if (permission.endsWith("SYSTEM_ALERT_WINDOW")) reasons.add("pode sobrepor a tela");
                    if (permission.endsWith("REQUEST_INSTALL_PACKAGES")) reasons.add("pode solicitar instalação de APKs");
                    if (permission.endsWith("BIND_ACCESSIBILITY_SERVICE")) reasons.add("declara permissão de acessibilidade");
                    if (permission.endsWith("READ_SMS") || permission.endsWith("RECEIVE_SMS")) reasons.add("acesso a SMS");
                    if (permission.endsWith("READ_CONTACTS")) reasons.add("acesso a contatos");
                }
            }
            boolean flagged = !reasons.isEmpty() && !system;
            if (flagged) suspicious++;

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(14, 10, 14, 10);
            card.setBackgroundColor(panel);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.setMargins(0, 0, 0, 10);
            results.addView(card, lp);

            String name;
            try { name = String.valueOf(ai.loadLabel(pm)); }
            catch (Exception ex) { name = p.packageName; }
            card.addView(text(name, 16, white));
            card.addView(text(p.packageName + (system ? " • sistema" : " • instalado pelo usuário"), 12, muted));
            if (flagged) {
                card.addView(text("VERIFICAR: " + join(reasons), 13, Color.rgb(255, 190, 95)));
            } else {
                card.addView(text(system ? "Aplicativo do sistema (não avaliado como suspeito)" : "Nenhum indicador simples encontrado", 13, muted));
            }
        }
        summary.setText("Análise concluída\nPacotes visíveis: " + packages.size()
                + "\nApps não sistêmicos: " + userApps
                + "\nApps para verificar: " + suspicious
                + "\n\nNenhum aplicativo foi removido ou alterado.");
        Toast.makeText(this, "Análise concluída", Toast.LENGTH_SHORT).show();
    }

    private String join(List<String> values) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) b.append(", ");
            b.append(values.get(i));
        }
        return b.toString();
    }
}
